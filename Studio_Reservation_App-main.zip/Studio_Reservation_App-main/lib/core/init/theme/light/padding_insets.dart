import 'package:flutter/cupertino.dart';

class PaddingInsets {
  final lowPaddingAll = const EdgeInsets.all(8.0);
}
