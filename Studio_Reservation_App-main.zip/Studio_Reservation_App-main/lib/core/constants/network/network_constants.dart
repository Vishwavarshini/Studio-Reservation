class NetworkConstants {
  static const baseUrl = "https://192.168.1.24:7155/api";
}
