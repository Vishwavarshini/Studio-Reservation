# Studio Reservation App

I've built this app as my internship  project. My goal was making reservation process in studio's or gym's better. With this app user can easily select the lesson which he/she wants to enroll in desired branch. Beside that user can manage and organize the lessons for its own use. Take a look at the video below to see how app works.



https://user-images.githubusercontent.com/56032031/192074092-eef44db5-d9f1-46bd-a9ce-16c1b20ee04b.mp4

